# src DIR

to archive source files for pattern recognition for UART input (RTL designs)
